"""filesource URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from datasource import views

# app_name = 'fileupload'

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.home),
    path('import/', views.import_data),
    path('export/', views.export_data),
    # path('dbcreation/', views.dbcreation),
    path('sample/', views.sample),
    path('api/fileupload/', views.FileUploadListCrtApi.as_view(), name='fileupload'),
    path('api/workspace/', views.CreateDBListCrtApi.as_view(), name='workspace'),
    path('api/tableinfo/', views.TableDataListCrtApi.as_view(), name='tableInfo'),
    path('api/dtype/', views.DatatypeListCrtApi.as_view(), name='DataTypeInfo'),
    path('api/file/', views.FileUploadViewSet, name='file_upload'),
    path('api/datatype/',views.FindDataTypeListCrtApi.as_view(), name='Find_DataType'),
    path('UserModel/',views.UserModelListCrtApi.as_view()),
    path('UserLogin/',views.UserLoginViewJwt.as_view()),
    path('workspace/',views.WorkSpaceSerializerListCrtApi.as_view()),
]
